#!/bin/bash
FIFO="/tmp/run/cuckoo.pid"
LOG="cuckoo.log"
DATE_CMD="date '+%Y-%m-%d %H:%M:%S'"

mkdir -p /tmp/run || exit 1
if [ ! -p "$FIFO" ]; then
    rm -f "$FIFO"
    mkfifo "$FIFO" || exit 1
fi

log() {
    echo "$($DATE_CMD) $1" >> "$LOG"
}

shutdown() {
    log "Shutdown!"
    rm -f "$FIFO"
    exit 0
}
trap shutdown SIGTERM SIGINT

log "Startup!"

exec 3<> "$FIFO"
while true; do
    if read -r line <&3; then
        if [[ "$line" =~ ^([A-Za-z0-9_]+)\[([0-9]+)\]:\ how\ much\ time\ do\ I\ have\?$ ]]; then
            name="${BASH_REMATCH[1]}"
            pid="${BASH_REMATCH[2]}"
            N=$(( RANDOM % 9 + 2 ))
            log "$name[$pid] $N"
            echo "$N" >&3
        fi
    else
        sleep 1
    fi
done
