#!/bin/bash
DATE_CMD="date '+%Y-%m-%d %H:%M:%S'"
SCRIPT_NAME=$(basename "$0")
FIFO="/tmp/run/cuckoo.pid"
if [ "$SCRIPT_NAME" = "template_task.sh" ]; then
    echo "я бригадир, сам не работаю"
    exit 1
fi
LOG_FILE="report_${SCRIPT_NAME}.log"
PID=$$
echo "$($DATE_CMD) [$PID] Скрипт запущен" >> "$LOG_FILE"
if [ ! -p "$FIFO" ]; then
    echo "Ошибка: FIFO $FIFO не существует. Запустите cuckoo.sh." >> "$LOG_FILE"
    exit 1
fi
exec 3<> "$FIFO"
echo "${SCRIPT_NAME}[${PID}]: how much time do I have?" >&3
read -r N <&3
exec 3>&-
sleep "$N"
echo "$($DATE_CMD) [$PID] Скрипт завершился, работал $N секунд." >> "$LOG_FILE"
