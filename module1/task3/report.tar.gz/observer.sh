#!/bin/bash
CONFIG="observer.conf"
LOG="observer.log"

log() {
    echo "$(date) $1" >> "$LOG"
}

if [ ! -f "$CONFIG" ]; then
    log "Файл конфигурации $CONFIG не найден"
    exit 1
fi

while IFS= read -r script_path; do
    [ -z "$script_path" ] && continue
    script_name=$(basename "$script_path")
    if pgrep -x "$script_name" > /dev/null 2>&1; then
        log "$script_name уже запущен"
    else
        nohup "$script_path" > /dev/null 2>&1 &
        log "restarted $script_name (PID $!)"
    fi
done < "$CONFIG"
